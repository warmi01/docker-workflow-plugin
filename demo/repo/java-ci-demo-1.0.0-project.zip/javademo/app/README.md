# Holds app and unit test source for the demoapp
Maven build will generate binary under the target directory