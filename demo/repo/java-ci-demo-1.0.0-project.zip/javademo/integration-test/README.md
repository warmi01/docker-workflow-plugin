# Holds source for integration tests
Maven build will generate binary under the target directory
