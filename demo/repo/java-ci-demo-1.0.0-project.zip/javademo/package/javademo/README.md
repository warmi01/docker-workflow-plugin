#README for javademo

Syndicate javademo with included Jenkins workflow



 

