#/usr/bin/env bash

echo "Testing that javademo service is available...."

# check for required first argument (app instance id)
if [ $# -lt 1 ]; then
    echo "Usage: test.sh <app instance id> [<domain>]"
    exit 1
fi

APP_INST_ID=$1
shift

if [ $# -gt 0 ]; then
  appfulldomain=$1
  shift
fi

if [ x$appfulldomain == x ]; then
  domaininfo=$(cat ~/instance-config/domaininfo.yml)
  appfulldomain=$(expr "$domaininfo" : ".*appfulldomain: \(.*\)developerkey:")
fi

function probe
{
  SR=$1
  echo Probing $SR
  code=1 # assume failure
  
  response=$(curl -s -X GET "$SR" --write-out "\\ncode:%{http_code}" -H "Accept:application/json")
  responsecode=$(expr "$response" : ".*code:\(.*\)")
  if [ x$responsecode != x200 ]; then
    echo FAILED:
    echo $response
    code=$responsecode
    exit $code
  else
    echo SUCCESS: Response code $responsecode
    code=0
  fi
}

probe http://serviceregistry-$appfulldomain/javademo

exit 0